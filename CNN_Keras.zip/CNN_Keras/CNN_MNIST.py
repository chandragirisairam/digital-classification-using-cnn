import numpy as np
import pickle
from sklearn import model_selection
from tensorflow.keras import layers, models
from MNIST_Dataset_Loader.mnist_loader import MNIST
import matplotlib.pyplot as plt
from matplotlib import style
style.use('ggplot')

# Load MNIST Data
print('\nLoading MNIST Data...')
data = MNIST('./MNIST_Dataset_Loader/dataset/')

# Loading Training Data
print('\nLoading Training Data...')
img_train, labels_train = data.load_training()
train_img = np.array(img_train) / 255.0  # Normalize pixel values to be between 0 and 1
train_labels = np.array(labels_train)

# Loading Testing Data
print('\nLoading Testing Data...')
img_test, labels_test = data.load_testing()
test_img = np.array(img_test) / 255.0  # Normalize pixel values to be between 0 and 1
test_labels = np.array(labels_test)

# Reshape the data for CNN
train_img = train_img.reshape((-1, 28, 28, 1))
test_img = test_img.reshape((-1, 28, 28, 1))

# Features
X = train_img

# Labels
y = train_labels

# Prepare Classifier Training and Testing Data
print('\nPreparing Classifier Training and Validation Data...')
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=0.1)

# Build the CNN model
model = models.Sequential()
model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(64, (3, 3), activation='relu'))
model.add(layers.MaxPooling2D((2, 2)))
model.add(layers.Conv2D(64, (3, 3), activation='relu'))
model.add(layers.Flatten())
model.add(layers.Dense(64, activation='relu'))
model.add(layers.Dense(10, activation='softmax'))

# Compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Train the model
print('\nTraining CNN...')
model.fit(X_train, y_train, epochs=5, validation_data=(X_test, y_test))

# Save the model
model.save('MNIST_CNN.h5')

# Evaluate the model on the test set
print('\nEvaluating CNN on Test Data...')
test_loss, test_acc = model.evaluate(test_img, test_labels)
print(f'Test Accuracy: {test_acc}')

# Making Predictions on Test Input Images
print('\nMaking Predictions on Test Input Images...')
predictions = model.predict(test_img)
test_labels_pred = np.argmax(predictions, axis=1)

# Creating Confusion Matrix for Test Data
print('\nCreating Confusion Matrix for Test Data...')
conf_mat_test = confusion_matrix(test_labels, test_labels_pred)

print('\nPredicted Labels for Test Images: ', test_labels_pred)
print('\nConfusion Matrix for Test Data: \n', conf_mat_test)

# Plot Confusion Matrix for Test Data
plt.matshow(conf_mat_test)
plt.title('Confusion Matrix for Test Data')
plt.colorbar()
plt.ylabel('True label')
plt.xlabel('Predicted label')
plt.axis('off')
plt.show()

# Show the Test Images with Original and Predicted Labels
num_images_to_display = 20
random_indices = np.random.choice(len(test_img), num_images_to_display, replace=False)
for i in random_indices:
    two_d = (np.reshape(test_img[i], (28, 28)) * 255).astype(np.uint8)
    plt.title(f'Original Label: {test_labels[i]}  Predicted Label: {test_labels_pred[i]}')
    plt.imshow(two_d, interpolation='nearest', cmap='gray')
    plt.show()
